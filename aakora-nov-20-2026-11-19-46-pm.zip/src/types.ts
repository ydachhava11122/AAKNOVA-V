export type RoleCode =
  | 'FOUNDER_SUPER_ADMIN'
  | 'INSTITUTION_ADMIN'
  | 'PRINCIPAL'
  | 'ACCOUNTANT'
  | 'TEACHER'
  | 'STAFF'
  | 'PARENT'
  | 'STUDENT';

export interface InstitutionSummary {
  id: number;
  institution_code: string;
  name: string;
  short_name: string;
  email?: string;
  phone?: string;
  address?: string;
  city: string;
  country?: string;
  academic_year?: string;
  currency_symbol: string;
  subscription_plan: 'Standard' | 'Professional' | 'Enterprise';
  annual_license_fee?: number;
  status: 'active' | 'suspended';
  student_count?: number;
  teacher_count?: number;
  staff_count?: number;
  collected_fees?: number;
  admin_email?: string;
  created_at?: string;
}

export interface AuthUser {
  id: number;
  institutionId: number | null;
  institutionCode: string | null;
  institutionName: string | null;
  username: string;
  email: string;
  mobile: string;
  fullName: string;
  roleId: number;
  roleCode: RoleCode;
  roleName: string;
  isFounder: boolean;
  status: string;
  theme: 'light' | 'dark' | 'system';
  language: string;
  notifyEmail: boolean;
  notifyPush: boolean;
  emailVerified: boolean;
  permissions: string[];
  csrfToken: string;
  studentId: number | null;
  teacherId: number | null;
  parentId: number | null;
  linkedStudentIds: number[];
}

export interface ProvisionedInstitutionCred {
  institutionId: number;
  institutionCode: string;
  institutionName: string;
  adminEmail: string;
  adminTemporaryPassword: string;
}

export type ModuleKey =
  | 'founder_dashboard'
  | 'institutions'
  | 'dashboard'
  | 'students'
  | 'teachers'
  | 'staff'
  | 'attendance'
  | 'fees'
  | 'exams'
  | 'timetable'
  | 'notices'
  | 'library'
  | 'transport'
  | 'parents'
  | 'certificates'
  | 'reports'
  | 'governance'
  | 'backups'
  | 'settings';

export interface Course {
  id: number;
  code: string;
  name: string;
  department: string;
  duration_months: number;
  annual_tuition: number;
  student_count?: number;
  class_count?: number;
}

export interface AcademicClass {
  id: number;
  course_id: number;
  name: string;
  section: string;
  academic_year: string;
  room_number: string;
  capacity: number;
  course_name?: string;
  course_code?: string;
  student_count?: number;
}

export interface Subject {
  id: number;
  course_id: number;
  code: string;
  name: string;
  max_marks: number;
  pass_marks: number;
  credits: number;
  course_name?: string;
}

export interface StudentRecord {
  id: number;
  student_code: string;
  admission_number: string;
  full_name: string;
  email: string;
  phone: string;
  date_of_birth: string;
  gender: string;
  address: string;
  course_id: number;
  class_id: number;
  course_name: string;
  course_code: string;
  class_name: string;
  class_section: string;
  guardian_name: string;
  guardian_phone: string;
  guardian_email: string;
  admission_date: string;
  status: 'active' | 'graduated' | 'suspended' | 'archived';
}

export interface TeacherRecord {
  id: number;
  teacher_code: string;
  full_name: string;
  email: string;
  phone: string;
  qualification: string;
  specialization: string;
  department: string;
  hire_date: string;
  work_schedule: string;
  performance_rating: number;
  status: 'active' | 'on_leave' | 'archived';
}

export interface StaffRecord {
  id: number;
  staff_code: string;
  full_name: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  hire_date: string;
  shift_schedule: string;
  monthly_salary: number;
  status: 'active' | 'on_leave' | 'archived';
}

export interface NotificationRecord {
  id: number;
  title: string;
  message: string;
  category: string;
  is_read: number;
  created_at: string;
}
