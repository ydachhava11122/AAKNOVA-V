import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import { seedSampleMultiTenantInstitutions } from '../db/seed.ts';
import {
  generateSecureToken,
  hashPassword,
  sha256,
  validatePasswordPolicy,
  verifyPassword,
} from '../security/crypto.ts';
import {
  getClientIp,
  loadAuthUserFromSession,
  rateLimit,
  recordAudit,
  recordLoginHistory,
  requireAuth,
  requireCsrf,
  sanitizeText,
  SESSION_COOKIE_NAME,
} from '../security/middleware.ts';

const router = Router();

function setSessionCookie(res: import('express').Response, rawToken: string, rememberMe: boolean, req: import('express').Request) {
  const maxAge = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 12 * 60 * 60 * 1000;
  const isSecure = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.cookie(SESSION_COOKIE_NAME, rawToken, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isSecure,
    path: '/',
    maxAge,
  });
}

function createSession(
  userId: number,
  rememberMe: boolean,
  req: import('express').Request
): { rawToken: string; csrfToken: string } {
  const db = getDb();
  const rawToken = generateSecureToken(32);
  const tokenHash = sha256(rawToken);
  const csrfToken = generateSecureToken(24);
  const ttlMs = rememberMe ? 30 * 24 * 60 * 60 * 1000 : 12 * 60 * 60 * 1000;
  const expiresAt = new Date(Date.now() + ttlMs).toISOString();

  db.prepare(
    `INSERT INTO sessions (token_hash, user_id, csrf_token, remember_me, ip_address, user_agent, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(tokenHash, userId, csrfToken, rememberMe ? 1 : 0, getClientIp(req), String(req.headers['user-agent'] || '').slice(0, 240), expiresAt);

  return { rawToken, csrfToken };
}

router.get('/setup-status', (_req, res) => {
  const db = getDb();
  const founderCount = db
    .prepare(
      `SELECT COUNT(*) as c FROM users u
       JOIN roles r ON r.id = u.role_id
       WHERE r.code = 'FOUNDER_SUPER_ADMIN'`
    )
    .get() as { c: number };
  const instCount = db.prepare('SELECT COUNT(*) as c FROM institutions').get() as { c: number };
  res.json({
    needsSetup: founderCount.c === 0,
    institutionCount: instCount.c,
    platformName: 'AAKNOVA',
  });
});

const provisionSchema = z.object({
  fullName: z.string().min(2).max(120),
  username: z.string().min(3).max(50).regex(/^[a-zA-Z0-9._-]+$/, 'Username may contain only letters, digits, dots, underscores, or hyphens.'),
  email: z.string().email().max(160),
  mobile: z.string().max(30).optional().default(''),
  password: z.string().min(8).max(128),
  seedSampleInstitutions: z.boolean().optional().default(true),
});

router.post('/provision-founder', rateLimit('provision', 10, 15 * 60 * 1000), (req, res) => {
  const db = getDb();
  const existingFounder = db
    .prepare(
      `SELECT COUNT(*) as c FROM users u
       JOIN roles r ON r.id = u.role_id
       WHERE r.code = 'FOUNDER_SUPER_ADMIN'`
    )
    .get() as { c: number };

  if (existingFounder.c > 0) {
    res.status(409).json({ error: 'Founder Super Admin has already been provisioned. Please sign in.' });
    return;
  }

  const parsed = provisionSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid provisioning input.' });
    return;
  }

  const { fullName, username, email, mobile, password, seedSampleInstitutions } = parsed.data;
  const policy = validatePasswordPolicy(password);
  if (!policy.valid) {
    res.status(400).json({ error: policy.errors.join(' ') });
    return;
  }

  const founderRole = db.prepare("SELECT id FROM roles WHERE code = 'FOUNDER_SUPER_ADMIN'").get() as { id: number };
  if (!founderRole) {
    res.status(500).json({ error: 'System RBAC roles are not initialized.' });
    return;
  }

  const cleanEmail = email.trim().toLowerCase();
  const cleanUsername = username.trim().toLowerCase();
  const cleanName = sanitizeText(fullName, 120);

  const insertRes = db
    .prepare(
      `INSERT INTO users (institution_id, username, email, mobile, full_name, password_hash, role_id, status, email_verified, last_login_at)
       VALUES (NULL, ?, ?, ?, ?, ?, ?, 'active', 1, datetime('now'))`
    )
    .run(cleanUsername, cleanEmail, sanitizeText(mobile, 30), cleanName, hashPassword(password), founderRole.id);

  const founderId = Number(insertRes.lastInsertRowid);

  let provisionedInstitutions: ReturnType<typeof seedSampleMultiTenantInstitutions> = [];
  if (seedSampleInstitutions) {
    provisionedInstitutions = seedSampleMultiTenantInstitutions(db, founderId);
  }

  const { rawToken } = createSession(founderId, true, req);
  setSessionCookie(res, rawToken, true, req);
  const loaded = loadAuthUserFromSession(rawToken);

  recordLoginHistory(req, {
    userId: founderId,
    institutionId: null,
    identifier: cleanEmail,
    outcome: 'success',
    reason: 'First-run Founder Super Admin provisioning',
  });
  recordAudit(
    req,
    'FOUNDER_PROVISIONED',
    'user',
    founderId,
    `First-run Founder Super Admin provisioned (${cleanEmail}); sampleInstitutions=${seedSampleInstitutions}`,
    { id: founderId, name: cleanName, role: 'FOUNDER_SUPER_ADMIN', institutionId: null }
  );

  res.status(201).json({
    message: 'AAKNOVA Founder Super Admin provisioned successfully.',
    user: loaded?.user,
    provisionedInstitutions,
  });
});

const loginSchema = z.object({
  identifier: z.string().min(2).max(160),
  password: z.string().min(1).max(128),
  rememberMe: z.boolean().optional().default(false),
});

router.post('/login', rateLimit('login', 25, 10 * 60 * 1000), (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Please provide your email/username and password.' });
    return;
  }

  const db = getDb();
  const ident = parsed.data.identifier.trim().toLowerCase();
  const userRow = db
    .prepare(
      `SELECT u.*, r.code as role_code, i.status as institution_status
       FROM users u
       JOIN roles r ON r.id = u.role_id
       LEFT JOIN institutions i ON i.id = u.institution_id
       WHERE lower(u.email) = ? OR lower(u.username) = ?`
    )
    .get(ident, ident) as Record<string, unknown> | undefined;

  if (!userRow) {
    recordLoginHistory(req, { identifier: ident, outcome: 'failed', reason: 'Account not found' });
    res.status(401).json({ error: 'Invalid credentials. Please check your email and password.' });
    return;
  }

  const userId = Number(userRow.id);
  const instId = userRow.institution_id ? Number(userRow.institution_id) : null;
  const roleCode = String(userRow.role_code);

  if (userRow.locked_until && new Date(String(userRow.locked_until)).getTime() > Date.now()) {
    recordLoginHistory(req, { userId, institutionId: instId, identifier: ident, outcome: 'locked', reason: 'Temporary lockout active' });
    res.status(423).json({ error: 'Account temporarily locked after repeated failed sign-in attempts. Retry in 15 minutes.' });
    return;
  }

  if (userRow.status !== 'active') {
    recordLoginHistory(req, { userId, institutionId: instId, identifier: ident, outcome: 'suspended', reason: `Account status: ${userRow.status}` });
    res.status(403).json({ error: 'This account is suspended or inactive. Contact your administrator.' });
    return;
  }

  if (roleCode !== 'FOUNDER_SUPER_ADMIN' && instId && userRow.institution_status === 'suspended') {
    recordLoginHistory(req, { userId, institutionId: instId, identifier: ident, outcome: 'suspended', reason: 'Institution suspended by Founder' });
    res.status(403).json({ error: 'Your institution is currently suspended. Contact AAKNOVA Founder Governance.' });
    return;
  }

  const valid = verifyPassword(parsed.data.password, String(userRow.password_hash));
  if (!valid) {
    const attempts = Number(userRow.failed_login_attempts || 0) + 1;
    const lockUntil = attempts >= 5 ? new Date(Date.now() + 15 * 60 * 1000).toISOString() : null;
    db.prepare(`UPDATE users SET failed_login_attempts = ?, locked_until = ? WHERE id = ?`).run(attempts, lockUntil, userId);
    recordLoginHistory(req, {
      userId,
      institutionId: instId,
      identifier: ident,
      outcome: lockUntil ? 'locked' : 'failed',
      reason: `Incorrect password (attempt ${attempts}/5)`,
    });
    res.status(401).json({
      error: lockUntil
        ? 'Account locked for 15 minutes due to 5 consecutive failed attempts.'
        : 'Invalid credentials. Please check your email and password.',
    });
    return;
  }

  db.prepare(`UPDATE users SET failed_login_attempts = 0, locked_until = NULL, last_login_at = datetime('now') WHERE id = ?`).run(userId);
  const { rawToken } = createSession(userId, parsed.data.rememberMe, req);
  setSessionCookie(res, rawToken, parsed.data.rememberMe, req);
  const loaded = loadAuthUserFromSession(rawToken);

  recordLoginHistory(req, { userId, institutionId: instId, identifier: ident, outcome: 'success', reason: 'Authenticated session started' });
  recordAudit(req, 'AUTH_LOGIN', 'session', userId, `Signed in as ${userRow.email}`, {
    id: userId,
    name: String(userRow.full_name),
    role: roleCode,
    institutionId: instId,
  });

  res.json({ user: loaded?.user });
});

router.post('/logout', requireAuth, requireCsrf, (req, res) => {
  const db = getDb();
  if (req.sessionTokenHash) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(req.sessionTokenHash);
  }
  recordAudit(req, 'AUTH_LOGOUT', 'session', req.user!.id, 'Signed out cleanly');
  res.clearCookie(SESSION_COOKIE_NAME, { path: '/' });
  res.json({ message: 'Signed out successfully.' });
});

router.get('/me', requireAuth, (req, res) => {
  const db = getDb();
  let institutions: Record<string, unknown>[] = [];
  if (req.user!.isFounder) {
    institutions = db
      .prepare('SELECT id, institution_code, name, short_name, city, subscription_plan, status, currency_symbol FROM institutions ORDER BY id ASC')
      .all() as Record<string, unknown>[];
  } else if (req.user!.institutionId) {
    institutions = db
      .prepare('SELECT id, institution_code, name, short_name, city, subscription_plan, status, currency_symbol FROM institutions WHERE id = ?')
      .all(req.user!.institutionId) as Record<string, unknown>[];
  }
  res.json({ user: req.user, institutions });
});

router.post('/forgot-password', rateLimit('forgot', 10, 15 * 60 * 1000), (req, res) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  if (!email) {
    res.status(400).json({ error: 'Email address is required.' });
    return;
  }
  const db = getDb();
  const user = db.prepare('SELECT id, email, full_name, institution_id FROM users WHERE lower(email) = ?').get(email) as
    | { id: number; email: string; full_name: string; institution_id: number | null }
    | undefined;

  if (!user) {
    res.json({
      message: 'If an account matches that email, a single-use recovery token has been generated.',
    });
    return;
  }

  const rawToken = generateSecureToken(18);
  const tokenHash = sha256(rawToken);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

  db.prepare(`INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?, ?, ?)`).run(user.id, tokenHash, expiresAt);
  recordAudit(req, 'PASSWORD_RESET_REQUESTED', 'user', user.id, `Reset token issued for ${user.email}`, {
    id: user.id,
    name: user.full_name,
    role: 'USER',
    institutionId: user.institution_id,
  });

  // In local/sandbox deployments without SMTP configured, return the time-limited token so recovery can be tested end-to-end
  res.json({
    message: 'Single-use password reset token generated (expires in 30 minutes).',
    resetToken: rawToken,
    expiresAt,
  });
});

const resetSchema = z.object({
  token: z.string().min(10),
  newPassword: z.string().min(8).max(128),
});

router.post('/reset-password', rateLimit('reset', 15, 15 * 60 * 1000), (req, res) => {
  const parsed = resetSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Valid reset token and new password are required.' });
    return;
  }
  const policy = validatePasswordPolicy(parsed.data.newPassword);
  if (!policy.valid) {
    res.status(400).json({ error: policy.errors.join(' ') });
    return;
  }

  const db = getDb();
  const tokenHash = sha256(parsed.data.token.trim());
  const row = db
    .prepare(`SELECT * FROM password_reset_tokens WHERE token_hash = ? AND used_at IS NULL`)
    .get(tokenHash) as { id: number; user_id: number; expires_at: string } | undefined;

  if (!row || new Date(row.expires_at).getTime() < Date.now()) {
    res.status(400).json({ error: 'Reset token is invalid or expired.' });
    return;
  }

  const tx = db.transaction(() => {
    db.prepare(`UPDATE users SET password_hash = ?, failed_login_attempts = 0, locked_until = NULL, updated_at = datetime('now') WHERE id = ?`).run(
      hashPassword(parsed.data.newPassword),
      row.user_id
    );
    db.prepare(`UPDATE password_reset_tokens SET used_at = datetime('now') WHERE id = ?`).run(row.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(row.user_id);
  });
  tx();

  recordAudit(req, 'PASSWORD_RESET_COMPLETED', 'user', row.user_id, 'Password reset completed and active sessions revoked', {
    id: row.user_id,
    name: 'Account Recovery',
    role: 'USER',
    institutionId: null,
  });

  res.json({ message: 'Password updated successfully. You may now sign in with your new password.' });
});

router.post('/change-password', requireAuth, requireCsrf, (req, res) => {
  const currentPassword = String(req.body?.currentPassword || '');
  const newPassword = String(req.body?.newPassword || '');
  const policy = validatePasswordPolicy(newPassword);
  if (!policy.valid) {
    res.status(400).json({ error: policy.errors.join(' ') });
    return;
  }

  const db = getDb();
  const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user!.id) as { password_hash: string };
  if (!verifyPassword(currentPassword, row.password_hash)) {
    res.status(400).json({ error: 'Current password is incorrect.' });
    return;
  }

  db.prepare(`UPDATE users SET password_hash = ?, updated_at = datetime('now') WHERE id = ?`).run(hashPassword(newPassword), req.user!.id);
  recordAudit(req, 'PASSWORD_CHANGED', 'user', req.user!.id, 'User updated account password');
  res.json({ message: 'Password changed successfully.' });
});

router.patch('/profile', requireAuth, requireCsrf, (req, res) => {
  const db = getDb();
  const fullName = req.body?.fullName ? sanitizeText(req.body.fullName, 120) : req.user!.fullName;
  const mobile = req.body?.mobile !== undefined ? sanitizeText(req.body.mobile, 30) : req.user!.mobile;
  const theme = ['light', 'dark', 'system'].includes(req.body?.theme) ? req.body.theme : req.user!.theme;
  const language = typeof req.body?.language === 'string' ? sanitizeText(req.body.language, 10) : req.user!.language;
  const notifyEmail = req.body?.notifyEmail !== undefined ? (req.body.notifyEmail ? 1 : 0) : req.user!.notifyEmail ? 1 : 0;
  const notifyPush = req.body?.notifyPush !== undefined ? (req.body.notifyPush ? 1 : 0) : req.user!.notifyPush ? 1 : 0;

  db.prepare(
    `UPDATE users SET full_name = ?, mobile = ?, theme = ?, language = ?, notify_email = ?, notify_push = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(fullName, mobile, theme, language, notifyEmail, notifyPush, req.user!.id);

  recordAudit(req, 'PROFILE_UPDATED', 'user', req.user!.id, 'Updated user profile and theme preferences');
  const token = req.cookies?.[SESSION_COOKIE_NAME];
  const refreshed = token ? loadAuthUserFromSession(token) : null;
  res.json({ user: refreshed?.user || req.user, message: 'Profile saved.' });
});

export default router;
