import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

function computeGrade(pct: number): string {
  if (pct >= 90) return 'A+';
  if (pct >= 80) return 'A';
  if (pct >= 70) return 'B+';
  if (pct >= 60) return 'B';
  if (pct >= 50) return 'C';
  if (pct >= 40) return 'D';
  return 'F';
}

router.get('/', requirePermission('exams.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;

  const examinations = db
    .prepare(
      `SELECT e.*, c.name as course_name, cl.name as class_name, cl.section as class_section,
        (SELECT COUNT(*) FROM results r WHERE r.examination_id = e.id AND r.institution_id = e.institution_id) as result_count
       FROM examinations e
       JOIN courses c ON c.id = e.course_id
       JOIN classes cl ON cl.id = e.class_id
       WHERE e.institution_id = ?
       ORDER BY e.start_date DESC`
    )
    .all(tid);

  const results = db
    .prepare(
      `SELECT r.*, e.name as exam_name, s.full_name as student_name, s.student_code, sub.name as subject_name, sub.code as subject_code
       FROM results r
       JOIN examinations e ON e.id = r.examination_id
       JOIN students s ON s.id = r.student_id
       JOIN subjects sub ON sub.id = r.subject_id
       WHERE r.institution_id = ?
       ORDER BY r.updated_at DESC`
    )
    .all(tid);

  res.json({ examinations, results });
});

router.post('/', requirePermission('exams.manage'), (req, res) => {
  const schema = z.object({
    name: z.string().min(2).max(140),
    examType: z.string().max(40).optional().default('Midterm'),
    courseId: z.coerce.number().int().positive(),
    classId: z.coerce.number().int().positive(),
    academicYear: z.string().max(24).optional().default('2026-2027'),
    startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    status: z.enum(['draft', 'scheduled', 'published']).optional().default('scheduled'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid examination input.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const course = db.prepare('SELECT id FROM courses WHERE id = ? AND institution_id = ?').get(d.courseId, tid);
  const cls = db.prepare('SELECT id FROM classes WHERE id = ? AND institution_id = ?').get(d.classId, tid);
  if (!course || !cls) {
    res.status(400).json({ error: 'Selected course or class does not belong to this institution.' });
    return;
  }
  const r = db
    .prepare(
      `INSERT INTO examinations (institution_id, name, exam_type, course_id, class_id, academic_year, start_date, end_date, status, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(tid, sanitizeText(d.name, 140), sanitizeText(d.examType, 40), d.courseId, d.classId, sanitizeText(d.academicYear, 24), d.startDate, d.endDate, d.status, req.user!.id);

  recordAudit(req, 'EXAM_CREATED', 'examination', Number(r.lastInsertRowid), `Scheduled exam ${d.name}`);
  res.status(201).json({ examination: db.prepare('SELECT * FROM examinations WHERE id = ?').get(r.lastInsertRowid) });
});

router.patch('/:id/status', requirePermission('exams.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const status = req.body?.status;
  if (!['draft', 'scheduled', 'published'].includes(status)) {
    res.status(400).json({ error: 'Invalid exam status.' });
    return;
  }
  const db = getDb();
  const r = db
    .prepare(`UPDATE examinations SET status = ?, published_at = CASE WHEN ? = 'published' THEN datetime('now') ELSE published_at END WHERE id = ? AND institution_id = ?`)
    .run(status, status, id, tid);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Examination not found in this institution.' });
    return;
  }
  recordAudit(req, 'EXAM_STATUS_UPDATED', 'examination', id, `Exam status set to ${status}`);
  res.json({ message: `Examination status updated to ${status}.` });
});

router.delete('/:id', requirePermission('exams.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const r = db.prepare('DELETE FROM examinations WHERE id = ? AND institution_id = ?').run(id, tid);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Examination not found in this institution.' });
    return;
  }
  recordAudit(req, 'EXAM_DELETED', 'examination', id, 'Deleted examination');
  res.json({ message: 'Examination deleted.' });
});

router.post('/results', requirePermission('exams.manage'), (req, res) => {
  const schema = z.object({
    examinationId: z.coerce.number().int().positive(),
    studentId: z.coerce.number().int().positive(),
    subjectId: z.coerce.number().int().positive(),
    marksObtained: z.coerce.number().min(0),
    maxMarks: z.coerce.number().positive().optional().default(100),
    remarks: z.string().max(200).optional().default(''),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid result entry.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  if (d.marksObtained > d.maxMarks) {
    res.status(400).json({ error: 'Marks obtained cannot exceed maximum marks.' });
    return;
  }

  const exam = db.prepare('SELECT id FROM examinations WHERE id = ? AND institution_id = ?').get(d.examinationId, tid);
  const student = db.prepare('SELECT id FROM students WHERE id = ? AND institution_id = ?').get(d.studentId, tid);
  const subject = db.prepare('SELECT id FROM subjects WHERE id = ? AND institution_id = ?').get(d.subjectId, tid);
  if (!exam || !student || !subject) {
    res.status(404).json({ error: 'Exam, student, or subject not found in this institution.' });
    return;
  }

  const pct = Math.round((d.marksObtained / d.maxMarks) * 1000) / 10;
  const grade = computeGrade(pct);

  const existing = db
    .prepare('SELECT id FROM results WHERE institution_id = ? AND examination_id = ? AND student_id = ? AND subject_id = ?')
    .get(tid, d.examinationId, d.studentId, d.subjectId) as { id: number } | undefined;

  let resultId: number;
  if (existing) {
    db.prepare(
      `UPDATE results SET marks_obtained = ?, max_marks = ?, percentage = ?, grade = ?, remarks = ?, entered_by = ?, updated_at = datetime('now')
       WHERE id = ?`
    ).run(d.marksObtained, d.maxMarks, pct, grade, sanitizeText(d.remarks, 200), req.user!.id, existing.id);
    resultId = existing.id;
  } else {
    const r = db
      .prepare(
        `INSERT INTO results (institution_id, examination_id, student_id, subject_id, marks_obtained, max_marks, percentage, grade, remarks, entered_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(tid, d.examinationId, d.studentId, d.subjectId, d.marksObtained, d.maxMarks, pct, grade, sanitizeText(d.remarks, 200), req.user!.id);
    resultId = Number(r.lastInsertRowid);
  }

  recordAudit(req, 'RESULT_SAVED', 'result', resultId, `Saved marks ${d.marksObtained}/${d.maxMarks} (${grade})`);
  res.status(201).json({ result: db.prepare('SELECT * FROM results WHERE id = ?').get(resultId) });
});

router.delete('/results/:id', requirePermission('exams.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const r = db.prepare('DELETE FROM results WHERE id = ? AND institution_id = ?').run(id, tid);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Result not found in this institution.' });
    return;
  }
  recordAudit(req, 'RESULT_DELETED', 'result', id, 'Deleted result record');
  res.json({ message: 'Result entry deleted.' });
});

export default router;
