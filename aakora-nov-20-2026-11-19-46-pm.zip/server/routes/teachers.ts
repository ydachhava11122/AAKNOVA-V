import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);
router.use(requireTenantScope);

router.get('/', requirePermission('teachers.view'), (req, res) => {
  const db = getDb();
  const tid = req.tenantId!;
  const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';

  let sql = 'SELECT * FROM teachers WHERE institution_id = ?';
  const params: unknown[] = [tid];
  if (q) {
    sql += ' AND (lower(full_name) LIKE ? OR lower(teacher_code) LIKE ? OR lower(department) LIKE ? OR lower(email) LIKE ?)';
    const like = `%${q}%`;
    params.push(like, like, like, like);
  }
  sql += ' ORDER BY id DESC';
  const teachers = db.prepare(sql).all(...params);
  res.json({ teachers });
});

const teacherSchema = z.object({
  fullName: z.string().min(2).max(120),
  email: z.string().email().max(160),
  phone: z.string().max(30).optional().default(''),
  qualification: z.string().max(120).optional().default(''),
  specialization: z.string().max(120).optional().default(''),
  department: z.string().min(2).max(80).optional().default('General'),
  hireDate: z.string().max(20).optional(),
  workSchedule: z.string().max(100).optional().default('Mon-Fri, 08:30-16:00'),
  performanceRating: z.coerce.number().min(0).max(5).optional().default(4.5),
  status: z.enum(['active', 'on_leave', 'archived']).optional().default('active'),
});

router.post('/', requirePermission('teachers.manage'), (req, res) => {
  const parsed = teacherSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid teacher data.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const email = d.email.trim().toLowerCase();

  const dup = db.prepare('SELECT id FROM teachers WHERE institution_id = ? AND lower(email) = ?').get(tid, email);
  if (dup) {
    res.status(409).json({ error: 'A faculty member with this email already exists in this institution.' });
    return;
  }

  const count = (db.prepare('SELECT COUNT(*) as c FROM teachers WHERE institution_id = ?').get(tid) as { c: number }).c;
  const code = `FAC-${tid}-${String(10 + count + Math.floor(Math.random() * 40))}`;

  const r = db
    .prepare(
      `INSERT INTO teachers (
        institution_id, teacher_code, full_name, email, phone, qualification, specialization,
        department, hire_date, work_schedule, performance_rating, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      tid,
      code,
      sanitizeText(d.fullName, 120),
      email,
      sanitizeText(d.phone, 30),
      sanitizeText(d.qualification, 120),
      sanitizeText(d.specialization, 120),
      sanitizeText(d.department, 80),
      d.hireDate || new Date().toISOString().slice(0, 10),
      sanitizeText(d.workSchedule, 100),
      d.performanceRating,
      d.status
    );

  const id = Number(r.lastInsertRowid);
  recordAudit(req, 'TEACHER_CREATED', 'teacher', id, `Added faculty member ${d.fullName}`);
  res.status(201).json({ teacher: db.prepare('SELECT * FROM teachers WHERE id = ?').get(id) });
});

router.put('/:id', requirePermission('teachers.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const existing = db.prepare('SELECT id FROM teachers WHERE id = ? AND institution_id = ?').get(id, tid);
  if (!existing) {
    res.status(404).json({ error: 'Teacher not found in this institution.' });
    return;
  }
  const parsed = teacherSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid update payload.' });
    return;
  }
  const d = parsed.data;
  db.prepare(
    `UPDATE teachers
     SET full_name = ?, email = ?, phone = ?, qualification = ?, specialization = ?, department = ?,
         work_schedule = ?, performance_rating = ?, status = ?, updated_at = datetime('now')
     WHERE id = ? AND institution_id = ?`
  ).run(
    sanitizeText(d.fullName, 120),
    d.email.trim().toLowerCase(),
    sanitizeText(d.phone, 30),
    sanitizeText(d.qualification, 120),
    sanitizeText(d.specialization, 120),
    sanitizeText(d.department, 80),
    sanitizeText(d.workSchedule, 100),
    d.performanceRating,
    d.status,
    id,
    tid
  );
  recordAudit(req, 'TEACHER_UPDATED', 'teacher', id, `Updated faculty member ${d.fullName}`);
  res.json({ teacher: db.prepare('SELECT * FROM teachers WHERE id = ?').get(id) });
});

router.delete('/:id', requirePermission('teachers.manage'), (req, res) => {
  const id = Number(req.params.id);
  const tid = req.tenantId!;
  const db = getDb();
  const existing = db.prepare('SELECT full_name FROM teachers WHERE id = ? AND institution_id = ?').get(id, tid) as
    | { full_name: string }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Teacher not found in this institution.' });
    return;
  }
  db.prepare('DELETE FROM teachers WHERE id = ? AND institution_id = ?').run(id, tid);
  recordAudit(req, 'TEACHER_DELETED', 'teacher', id, `Removed faculty member ${existing.full_name}`);
  res.json({ message: `Teacher ${existing.full_name} deleted.` });
});

export default router;
