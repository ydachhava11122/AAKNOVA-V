import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/connection.ts';
import {
  recordAudit,
  requireAuth,
  requireCsrf,
  requirePermission,
  requireTenantScope,
  sanitizeText,
} from '../security/middleware.ts';

const router = Router();
router.use(requireAuth);
router.use(requireCsrf);

router.get('/notifications', (req, res) => {
  const db = getDb();
  const notifications = db
    .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30')
    .all(req.user!.id);
  const unreadCount = (
    db.prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0').get(req.user!.id) as { c: number }
  ).c;
  res.json({ notifications, unreadCount });
});

router.patch('/notifications/:id/read', (req, res) => {
  const db = getDb();
  db.prepare(`UPDATE notifications SET is_read = 1, read_at = datetime('now') WHERE id = ? AND user_id = ?`).run(
    Number(req.params.id),
    req.user!.id
  );
  res.json({ message: 'Marked as read.' });
});

router.post('/notifications/read-all', (req, res) => {
  getDb()
    .prepare(`UPDATE notifications SET is_read = 1, read_at = datetime('now') WHERE user_id = ? AND is_read = 0`)
    .run(req.user!.id);
  res.json({ message: 'All notifications marked as read.' });
});

router.get('/notices', requireTenantScope, requirePermission('notices.view'), (req, res) => {
  const db = getDb();
  const notices = db
    .prepare(
      `SELECT n.*, u.full_name as author_name
       FROM notices n
       LEFT JOIN users u ON u.id = n.published_by
       WHERE n.institution_id = ? OR n.institution_id IS NULL
       ORDER BY n.created_at DESC`
    )
    .all(req.tenantId!);
  res.json({ notices });
});

router.post('/notices', requireTenantScope, requirePermission('notices.manage'), (req, res) => {
  const schema = z.object({
    title: z.string().min(3).max(160),
    content: z.string().min(5).max(3000),
    category: z.enum(['notice', 'announcement', 'alert']).optional().default('notice'),
    priority: z.enum(['normal', 'high', 'urgent']).optional().default('normal'),
    targetRoles: z.string().max(120).optional().default('ALL'),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid notice payload.' });
    return;
  }
  const db = getDb();
  const tid = req.tenantId!;
  const d = parsed.data;
  const r = db
    .prepare(
      `INSERT INTO notices (institution_id, title, content, category, priority, target_roles, published_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(tid, sanitizeText(d.title, 160), sanitizeText(d.content, 3000), d.category, d.priority, sanitizeText(d.targetRoles, 120), req.user!.id);
  const noticeId = Number(r.lastInsertRowid);

  // Dispatch in-app notification to active users in this institution
  const recipients = db
    .prepare("SELECT id FROM users WHERE status = 'active' AND (institution_id = ? OR institution_id IS NULL)")
    .all(tid) as { id: number }[];
  const insNotif = db.prepare(
    `INSERT INTO notifications (institution_id, user_id, notice_id, title, message, category) VALUES (?, ?, ?, ?, ?, ?)`
  );
  for (const rec of recipients) {
    insNotif.run(tid, rec.id, noticeId, sanitizeText(d.title, 160), sanitizeText(d.content, 240), d.category);
  }

  recordAudit(req, 'NOTICE_PUBLISHED', 'notice', noticeId, `Published ${d.category}: ${d.title}`);
  res.status(201).json({ notice: db.prepare('SELECT * FROM notices WHERE id = ?').get(noticeId) });
});

router.delete('/notices/:id', requireTenantScope, requirePermission('notices.manage'), (req, res) => {
  const id = Number(req.params.id);
  const r = getDb().prepare('DELETE FROM notices WHERE id = ? AND institution_id = ?').run(id, req.tenantId!);
  if (r.changes === 0) {
    res.status(404).json({ error: 'Notice not found in this institution.' });
    return;
  }
  recordAudit(req, 'NOTICE_DELETED', 'notice', id, 'Deleted notice');
  res.json({ message: 'Notice deleted.' });
});

export default router;
